<footer class="footer" style="background: <?php foreach ($data['website'] as $key=>$val){
    echo $val['color'].'!important';

    ?>;
        -webkit-box-shadow: -1px -2px 5px 0px rgba(0,0,0,0.75);
        -moz-box-shadow: -1px -2px 5px 0px rgba(0,0,0,0.75);
        box-shadow: -1px -2px 5px 0px rgba(0,0,0,0.75);
    font-family: <?php echo $val['font'].'!important'; ?> ;
color: black!important;
        <?php
}  ?>;">
    <div class="l-0" style="margin-left: 12px!important;">
        <div class="footer__w" >
            <div class="footer__services" >



            <div class="footer__g" >
                <div class="footer__logo"><a><img src="<?php echo URLROOT.'\public\shared\images\AG.png' ?>" width="80" alt="EssayPro"></a></div>
                &nbsp;&nbsp;&nbsp;  <div class="footer__n"><span data-link="https://essaypro.com/become-a-writer.html"
                                             class="footer__n-a ga-event h-l" data-ga-category="home"
                                             data-ga-action="click" data-ga-label="home-header Become a writer click" style="color: black!important;">Become a writer</span><span data-link="https://essaypro.com/become-a-writer.html"
                                                                                                                                                  class="footer__n-a ga-event h-l" data-ga-category="home"
                                                                                                                                                  data-ga-action="click" data-ga-label="home-header Become a writer click" style="color: black!important;">Sign up</span>
                    <span data-link="https://essaypro.com/terms-and-conditions.html" class="footer__n-a ga-event h-l"
                          data-ga-category="home" data-ga-action="click"
                          data-ga-label="home-header Terms and Conditions click" style="color: black!important;">Terms and Conditions</span> <span
                            data-link="https://essaypro.com/refund-policy.html" class="footer__n-a ga-event h-l"
                            data-ga-category="home" data-ga-action="click"
                            data-ga-label="home-header Refund Policy click" style="color: black!important;">Refund Policy</span> <span
                            data-link="https://essaypro.com/privacy-policy.html" class="footer__n-a ga-event h-l"
                            data-ga-category="home" data-ga-action="click"
                            data-ga-label="home-header Privacy Policy click" style="color: black!important;">Privacy Policy</span> <span
                            data-link="nofollow-https://intercom.help/essaypro" class="footer__n-a ga-event h-l"
                            data-ga-category="home" data-ga-action="click"
                            data-ga-label="home-header FAQ click" style="color: black!important;">FAQ</span> <span
                            data-link="https://essaypro.com/contact-us.html" class="footer__n-a ga-event h-l"
                            data-ga-category="home" data-ga-action="click" data-ga-label="home-header Contact us click" style="color: black!important;">Contact us</span>
                </div>
            </div>
<!--            -->
<!--            <div class="footer__p-l">-->
<!---->
<!---->
<!--                <div class="footer__s"><span data-link="https://www.facebook.com/essayprocom/" class="a-1 fb h-l"-->
<!--                                             aria-label="facebook" ></span> <span-->
<!--                        data-link="https://www.youtube.com/channel/UCozQuQBYUISvnsyQ3sydO3w" class="a-1 yt h-l"-->
<!--                        aria-label="youtube"></span> <span data-link="https://twitter.com/essayprocom"-->
<!--                                                           class="a-1 tw h-l" aria-label="twitter"></span> <span-->
<!--                        data-link="https://www.instagram.com/essayprocom/" class="a-1 in h-l"-->
<!--                        aria-label="twitter"></span></div>-->
<!--            </div>-->
            <div class="footer__bottom">
                <div class="footer__c">© 2020 Assignment Guru. All rights reserved.</div>
                <div class="footer__statement">Assignment Guru will be listed on your bank statement.</div>
            </div>
        </div>
    </div>
</footer>