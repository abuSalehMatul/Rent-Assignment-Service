
<a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>

</div>


<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="<?php echo URLROOT.'/backend/';?>assets/js/app.min.js" type="152c77feee4b27fee47e2e52-text/javascript"></script>


<script src="<?php echo URLROOT.'/backend/';?>assets/plugins/apexcharts/dist/apexcharts.min.js" type="152c77feee4b27fee47e2e52-text/javascript"></script>
<script src="<?php echo URLROOT.'/backend/';?>assets/js/demo/dashboard.demo.js" type="152c77feee4b27fee47e2e52-text/javascript"></script>

<script type="152c77feee4b27fee47e2e52-text/javascript">
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','../../www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-53034621-1', 'auto');
	  ga('send', 'pageview');

	</script>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="152c77feee4b27fee47e2e52-|49" defer=""></script><script defer src="../../static.cloudflareinsights.com/beacon.min.js" data-cf-beacon='{"rayId":"5a085117bb7ae9a7","version":"2020.5.1","si":10}'></script>
</body>

<!-- Mirrored from seantheme.com/studio/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 09 Jun 2020 05:05:48 GMT -->
</html>
