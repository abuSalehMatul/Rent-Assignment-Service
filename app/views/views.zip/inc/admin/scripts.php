<?php
?>


<script src="<?php echo URLROOT.'/public/admin/assets/js/vendors/jquery-3.2.1.min.js';?>"></script>

<!-- BOOTSTRAP SCRIPTS JS-->
<script src="<?php echoURLROOT.'/public/admin/assets/plugins/bootstrap/js/bootstrap.bundle.min.js';?>"></script>

<!-- SPARKLINE JS -->
<script src="<?php echo URLROOT.'/public/admin/assets/js/vendors/jquery.sparkline.min.js';?>"></script>

<!-- CHART-CIRCLE JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/js/vendors/circle-progress.min.js';?>"></script>

<!-- PARTICLES JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/particles.js-master/particles.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/particles.js-master/particlesapp_bubble.js';?>"></script>

<!-- RATING STAR JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/rating/rating-stars.js';?>"></script>

<!-- CHARTJS CHART JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/chart/chart.bundle.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/chart/utils.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/js/chart.js';?>"></script>

<!-- INTERNAL PIETY CHART JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/peitychart/jquery.peity.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/peitychart/peitychart.init.js';?>"></script>

<!-- HORIZONTAL-MENU JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/horizontal-menu/horizontal-menu.js';?>"></script>

<!-- INTERNAL  APEX-CHARTS JS -->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/apexcharts/apexcharts.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/apexcharts/irregular-data-series.js';?>"></script>

<script src="<?php echo URLROOT.'/public/admin/assets/plugins/time-picker/time-picker.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/time-picker/toggles.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/date-picker/date-picker.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/date-picker/jquery-ui.js';?>"></script>
<!-- INTERNAL FLOT JS JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/flot/flot.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/flot/flot.pie.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/flot/jquery.flot.crosshair.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/flot/jquery.flot.resize.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/flot/chart.flot.sampledata.js';?>"></script>

<!-- P-SCROLL JS -->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/p-scroll/p-scroll.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/p-scroll/p-scroll-1.js';?>"></script>

<!-- SIDEBAR JS -->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/right-sidebar/right-sidebar.js';?>"></script>

<!-- INTERNAL COUNTERS JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/counters/counterup.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/counters/waypoints.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/counters/counters-1.js';?>"></script>

<!-- INTERNAL INDEX-SCRIPTS  JS-->
<script src="<?php echo URLROOT.'/public/admin/assets/js/index.js';?>"></script>

<!-- STICKY JS -->
<script src="<?php echo URLROOT.'/public/admin/assets/js/stiky.js';?>"></script>

<!-- CUSTOM JS -->
<script src="<?php echo URLROOT.'/public/admin/assets/js/custom.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/js/formelements.js';?>"></script>



//datatable


<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/jquery.dataTables.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/dataTables.bootstrap4.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/dataTables.buttons.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/buttons.bootstrap4.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/jszip.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/pdfmake.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/vfs_fonts.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/buttons.html5.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/buttons.print.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/js/buttons.colVis.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/dataTables.responsive.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/responsive.bootstrap4.min.js';?>"></script>
<script src="<?php echo URLROOT.'/public/admin/assets/plugins/datatable/datatable.js';?>"></script>