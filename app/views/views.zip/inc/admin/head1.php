<?php
?>


<meta charset="UTF-8">
<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
<meta content="Dashmint – Bootstrap Responsive Flat Admin Dashboard HTML5 Template" name="description">
<meta content="Spruko Technologies Private Limited" name="author">
<meta name="keywords" content="admin bootstrap 4 template, admin dashboard, admin dashboard template, admin panel html template, admin panel template, bootstrap 4 dashboard, modern admin template, bootstrap admin dashboard, bootstrap admin dashboard template, bootstrap admin template, bootstrap dashboard, bootstrap dashboard template, bootstrap simple dashboard, dashboard bootstrap 4, dashboard html css, dashboard template bootstrap 4, bootstrap control panel, template bootstrap 4 admin, simple bootstrap admin template, simple dashboard html template, simple dashboard template bootstrap"/>

<!--favicon -->
<link rel="icon" href="<?php echo URLROOT.'/public/admin/assets/images/brand/favicon.ico';?>" type="image/x-icon"/>


<!-- TITLE -->
<title>EssayLit.IO</title>

<!-- BOOTSTRAP CSS -->
<link href="<?php echo URLROOT.'/public/admin/assets/plugins/bootstrap/css/bootstrap.min.css';?>" rel="stylesheet">

<!-- DASHBOARD CSS -->
<link href="<?php echo URLROOT.'/public/admin/assets/css/style.css';?>" rel="stylesheet"/>
<link href="<?php echo URLROOT.'/public/admin/assets/css/skins-modes.css';?>" rel="stylesheet"/>
<!--<link href="--><?php //echo URLROOT.'/public/admin/assets/css/boxed.css';?><!--" rel="stylesheet"/>-->

<!-- HORIZONTAL-MENU CSS -->
<!--<link href="--><?php //echo URLROOT.'/public/admin/assets/plugins/horizontal-menu/dropdown-effects/fade-down.css';?><!--" rel="stylesheet">-->

<!--C3 CHARTS CSS -->
<link href="<?php echo URLROOT.'/public/admin/assets/plugins/charts-c3/c3-chart.css';?>" rel="stylesheet"/>

<!-- INTERNAL TABS CSS -->
<link href="<?php echo URLROOT.'/public/admin/assets/plugins/tabs/tabs-2.css';?>" rel="stylesheet" type="text/css">

<!-- P-SCROll CSS -->
<link href="<?php echo URLROOT.'/public/admin/assets/plugins/p-scroll/p-scroll.css';?>" rel="stylesheet" type="text/css">

<!--- FONT-ICONS CSS -->
<link href="<?php echo URLROOT.'/public/admin/assets/css/icons.css';?>" rel="stylesheet"/>
<!-- here open -->
<link href="<?php echo URLROOT.'/public/admin/assets/css/sidemenu.css';?>" rel="stylesheet"/>
<link href="<?php echo URLROOT.'/public/admin/assets/css/sidemenu-responsive-tabs.css';?>" rel="stylesheet"/>
<link href="<?php echo URLROOT.'/public/admin/assets/plugins/select2/select2.min.css';?>" rel="stylesheet"/>





<!-- here ends -->
<!-- SIDEBAR CSS -->
<link href="<?php echo URLROOT.'/public/admin/assets/plugins/right-sidebar/right-sidebar.css';?>" rel="stylesheet">

<!-- COLOR SKIN CSS -->
<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo URLROOT.'/public/admin/assets/css/color-skins/color11.css';?>" />

