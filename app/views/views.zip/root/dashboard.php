<?php
require_once APPROOT . '/helpers/sessionHelper.php';
echo 'root dashboard here';